function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5vKOvroQvZE":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

